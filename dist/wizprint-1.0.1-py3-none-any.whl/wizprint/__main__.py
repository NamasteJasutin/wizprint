from .__init__ import fnt, wprint

if __name__ == "__main__":
    wprint("\t\t\tHello, World", foreground=fnt.G, signed="🔧 NamasteJasutin")